This example demonstrates how to write new *custom* rules for the Java analyzer.

It requires to install the **Java Plugin**, at least version **3.10**, which is compatible with SonarQube 4.5.6 LTS.
