# Analyze this project with SonarQube

See http://docs.sonarqube.org/x/bAAW for details on how to analyze this project using the MSBuild SonarQube Runner.
