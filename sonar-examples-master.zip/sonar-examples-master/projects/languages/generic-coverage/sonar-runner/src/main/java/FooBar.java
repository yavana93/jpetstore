public class FooBar {

  public int process(int a) {
    if (a > 1 && a < 10) {
      return a;
    }
    return 0;
  }
  
}
