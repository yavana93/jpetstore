This example demonstrates how to analyze a simple Java project with the Sonar Runner.

Prerequisites
=============
* [SonarQube](http://www.sonarqube.org/downloads/) 4.5 or higher
* [SonarQube Runner](http://docs.sonarqube.org/display/SONAR/Analyzing+with+SonarQube+Runner) 2.4 or higher

Usage
=====
* Analyze the project with SonarQube using the SonarQube Runner:

        sonar-runner
