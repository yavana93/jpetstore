//
//  Other.m
//  helloworld
//

#import <Foundation/Foundation.h>

#import "Other.h"

@implementation Other
- (void)sayHello {
    NSLog(@"Hello, world!");
}
@end
