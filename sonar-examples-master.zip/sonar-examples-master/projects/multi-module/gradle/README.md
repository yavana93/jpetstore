A simple gradle project (no modules) is available at ../../languages/java/gradle/java-gradle-simple
