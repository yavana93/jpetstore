package example;

public class Greeting
{
    public void coveredByTest()
    {
       System.out.println("Hello, world.");
    }
}
